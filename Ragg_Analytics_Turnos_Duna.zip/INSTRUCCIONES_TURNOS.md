# PedidosYa por turno

## Orden de instalación

1. En Supabase, abrir **SQL Editor**.
2. Ejecutar completo el archivo `supabase_turnos_pedidosya.sql`.
3. Copiar los archivos de esta actualización sobre el proyecto `frontend`.
4. Desde PowerShell, dentro de `frontend`, ejecutar:

```powershell
npm run build
```

5. Si el build termina correctamente, publicar:

```powershell
git add .
git commit -m "Agregar análisis PedidosYa por turno"
git push
```

Vercel publicará automáticamente la nueva versión.

## Importaciones de Duna

Para Duna aparecerán opciones separadas:

- PedidosYa mediodía - ordersPerDay CSV
- PedidosYa mediodía - orderDetails CSV
- PedidosYa mediodía - resumen de productos Excel
- PedidosYa noche - ordersPerDay CSV
- PedidosYa noche - orderDetails CSV
- Paradise PDF
- Costos Duna Excel

Los archivos ya importados de Duna se migran automáticamente a
`mediodia`.

Se puede importar ahora `ordersPerDay` de noche. El dashboard mostrará
facturación, pedidos y ticket nocturno. Cuando se importen los
`orderDetails` nocturnos, se completarán automáticamente descuentos,
comisión, IVA, tarifa en línea, costos, ganancia y margen.

## Dashboard

En Duna aparecerá la sección **Análisis de PedidosYa por turno** con:

- Total PedidosYa
- Mediodía
- Noche

PIU conserva sus cálculos y solamente muestra sus tipos de importación.

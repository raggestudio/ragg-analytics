begin;

alter table public.importaciones
  add column if not exists turno text not null default 'general';

alter table public.ventas
  add column if not exists turno text not null default 'general';

alter table public.pedidosya_pedidos
  add column if not exists turno text not null default 'general';

alter table public.pedidosya_pedido_productos
  add column if not exists turno text not null default 'general';

alter table public.importaciones
  drop constraint if exists importaciones_turno_check;
alter table public.importaciones
  add constraint importaciones_turno_check
  check (turno in ('general', 'mediodia', 'noche'));

alter table public.ventas
  drop constraint if exists ventas_turno_check;
alter table public.ventas
  add constraint ventas_turno_check
  check (turno in ('general', 'mediodia', 'noche'));

alter table public.pedidosya_pedidos
  drop constraint if exists pedidosya_pedidos_turno_check;
alter table public.pedidosya_pedidos
  add constraint pedidosya_pedidos_turno_check
  check (turno in ('general', 'mediodia', 'noche'));

alter table public.pedidosya_pedido_productos
  drop constraint if exists pedidosya_productos_turno_check;
alter table public.pedidosya_pedido_productos
  add constraint pedidosya_productos_turno_check
  check (turno in ('general', 'mediodia', 'noche'));

update public.importaciones i
set turno = 'mediodia'
from public.empresas e
where e.id = i.empresa_id
  and e.tipo_negocio = 'restaurante'
  and i.tipo in (
    'pedidosya_csv',
    'pedidosya_productos_excel',
    'pedidosya_order_details_csv'
  )
  and i.turno = 'general';

update public.ventas v
set turno = 'mediodia'
from public.empresas e
where e.id = v.empresa_id
  and e.tipo_negocio = 'restaurante'
  and v.origen = 'PedidosYa'
  and v.turno = 'general';

update public.pedidosya_pedidos p
set turno = 'mediodia'
from public.empresas e
where e.id = p.empresa_id
  and e.tipo_negocio = 'restaurante'
  and p.turno = 'general';

update public.pedidosya_pedido_productos pp
set turno = coalesce(p.turno, 'mediodia')
from public.pedidosya_pedidos p
where p.id = pp.pedido_id;

alter table public.pedidosya_pedidos
  drop constraint if exists pedidosya_pedidos_empresa_id_numero_pedido_key;

create unique index if not exists
  pedidosya_pedidos_empresa_numero_turno_key
on public.pedidosya_pedidos (
  empresa_id,
  numero_pedido,
  turno
);

create index if not exists ventas_periodo_turno_idx
on public.ventas (
  empresa_id,
  periodo_id,
  sucursal_id,
  turno
);

create index if not exists pedidosya_pedidos_periodo_turno_idx
on public.pedidosya_pedidos (
  empresa_id,
  periodo_id,
  sucursal_id,
  turno
);

commit;
